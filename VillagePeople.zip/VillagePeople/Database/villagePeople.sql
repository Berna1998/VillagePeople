DROP SCHEMA IF EXISTS `villagepeople`;
CREATE SCHEMA IF NOT EXISTS `villagepeople`;
USE `villagepeople`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: villagepeople
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attivita`
--

DROP TABLE IF EXISTS `attivita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attivita` (
  `CodiceAttivita` int NOT NULL,
  `NomeAttivita` varchar(45) NOT NULL,
  `Prezzo` double NOT NULL,
  `CategoriaAttivita` int NOT NULL,
  `giorno` varchar(15) NOT NULL,
  `orario` varchar(10) NOT NULL,
  `tipologia` int NOT NULL,
  `numPartecipantiMax` int DEFAULT NULL,
  PRIMARY KEY (`CodiceAttivita`),
  KEY `fk_attivita_categoriaattivita1_idx` (`CategoriaAttivita`),
  CONSTRAINT `fk_attivita_categoriaattivita1` FOREIGN KEY (`CategoriaAttivita`) REFERENCES `categoriaattivita` (`idCategoriaAttivita`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attivita`
--

LOCK TABLES `attivita` WRITE;
/*!40000 ALTER TABLE `attivita` DISABLE KEYS */;
INSERT INTO `attivita` VALUES (2,'Mini Golf',8,1,'Giovedi','17:00',2,6),(3,'Burraco',5,3,'Martedi','17:00',2,4),(6,'Briscola',6,3,'Martedi','16:00',2,4),(11,'Sala Pesi',10,1,'Martedi','10:30',1,NULL),(23,'Paddle',12,1,'Giovedi','18:00',2,4),(53,'Basket',10,1,'Giovedi','16:00',2,4),(59,'Bowling',15,1,'Giovedi','20:00',2,8),(97,'Calciotto',20,1,'Domenica','15',2,16),(99,'Sauna',10,3,'Domenica','15:00',1,NULL);
/*!40000 ALTER TABLE `attivita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoriaattivita`
--

DROP TABLE IF EXISTS `categoriaattivita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoriaattivita` (
  `idCategoriaAttivita` int NOT NULL,
  `DescrizioneAttivita` varchar(45) NOT NULL,
  PRIMARY KEY (`idCategoriaAttivita`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoriaattivita`
--

LOCK TABLES `categoriaattivita` WRITE;
/*!40000 ALTER TABLE `categoriaattivita` DISABLE KEYS */;
INSERT INTO `categoriaattivita` VALUES (1,'Sport'),(2,'Salute&Benessere'),(3,'Svago&Realx'),(4,'Bambini');
/*!40000 ALTER TABLE `categoriaattivita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codicidisponibili`
--

DROP TABLE IF EXISTS `codicidisponibili`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `codicidisponibili` (
  `CodiceID` varchar(10) NOT NULL,
  `NomeUtente` varchar(45) NOT NULL,
  `CognomeUtente` varchar(45) NOT NULL,
  PRIMARY KEY (`CodiceID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codicidisponibili`
--

LOCK TABLES `codicidisponibili` WRITE;
/*!40000 ALTER TABLE `codicidisponibili` DISABLE KEYS */;
INSERT INTO `codicidisponibili` VALUES ('12348','Marco','Rossi'),('12555','Luca','Bianchi'),('999999','Cristiano','Ronaldo');
/*!40000 ALTER TABLE `codicidisponibili` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intolleranze`
--

DROP TABLE IF EXISTS `intolleranze`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `intolleranze` (
  `codiceCli` varchar(10) NOT NULL,
  `intolleranza` mediumtext NOT NULL,
  `data` date NOT NULL,
  `numMenu` int NOT NULL,
  PRIMARY KEY (`codiceCli`,`data`),
  KEY `data_idx` (`data`),
  CONSTRAINT `codiceCli` FOREIGN KEY (`codiceCli`) REFERENCES `utente` (`CodiceID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `data_ind` FOREIGN KEY (`data`) REFERENCES `menu` (`data`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intolleranze`
--

LOCK TABLES `intolleranze` WRITE;
/*!40000 ALTER TABLE `intolleranze` DISABLE KEYS */;
/*!40000 ALTER TABLE `intolleranze` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `codice` int NOT NULL,
  `descrizione` mediumtext NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`codice`,`data`),
  KEY `data_idx` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menuprenotati`
--

DROP TABLE IF EXISTS `menuprenotati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menuprenotati` (
  `codice` varchar(10) NOT NULL,
  `menu` int NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`codice`,`data`),
  KEY `data_idx` (`data`),
  KEY `menu_idx` (`menu`,`data`),
  CONSTRAINT `codice` FOREIGN KEY (`codice`) REFERENCES `utente` (`CodiceID`),
  CONSTRAINT `menu` FOREIGN KEY (`menu`, `data`) REFERENCES `menu` (`codice`, `data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menuprenotati`
--

LOCK TABLES `menuprenotati` WRITE;
/*!40000 ALTER TABLE `menuprenotati` DISABLE KEYS */;
/*!40000 ALTER TABLE `menuprenotati` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifiche`
--

DROP TABLE IF EXISTS `notifiche`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifiche` (
  `Notifiche` mediumtext NOT NULL,
  `IdCategoria` int DEFAULT NULL,
  `tipoNotifica` int NOT NULL,
  `data` date NOT NULL,
  `IdUtente` varchar(10) DEFAULT NULL,
  `codiceAttivita` int DEFAULT NULL,
  `idNotifica` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idNotifica`),
  KEY `IdCategoria_idx` (`IdCategoria`),
  KEY `IdUtente_idx` (`IdUtente`),
  CONSTRAINT `IdCategoria` FOREIGN KEY (`IdCategoria`) REFERENCES `categoriaattivita` (`idCategoriaAttivita`),
  CONSTRAINT `IdUtente` FOREIGN KEY (`IdUtente`) REFERENCES `utente` (`CodiceID`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifiche`
--

LOCK TABLES `notifiche` WRITE;
/*!40000 ALTER TABLE `notifiche` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifiche` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferenzeutente`
--

DROP TABLE IF EXISTS `preferenzeutente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferenzeutente` (
  `CodiceUtente` varchar(10) NOT NULL,
  `CodiceAttivitaPreferita` int NOT NULL,
  PRIMARY KEY (`CodiceUtente`,`CodiceAttivitaPreferita`),
  KEY `preferenzeutente_ibfk_2_idx` (`CodiceAttivitaPreferita`),
  CONSTRAINT `foreignKey_codiceUt` FOREIGN KEY (`CodiceUtente`) REFERENCES `utente` (`CodiceID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `preferenzeutente_ibfk_2` FOREIGN KEY (`CodiceAttivitaPreferita`) REFERENCES `categoriaattivita` (`idCategoriaAttivita`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferenzeutente`
--

LOCK TABLES `preferenzeutente` WRITE;
/*!40000 ALTER TABLE `preferenzeutente` DISABLE KEYS */;
/*!40000 ALTER TABLE `preferenzeutente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prenotazioniattivita`
--

DROP TABLE IF EXISTS `prenotazioniattivita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prenotazioniattivita` (
  `IdPrenotazione` int NOT NULL AUTO_INCREMENT,
  `CodiceUtente` varchar(10) NOT NULL,
  `CodiceAttivita` int NOT NULL,
  PRIMARY KEY (`CodiceUtente`,`CodiceAttivita`),
  UNIQUE KEY `IdPrenotazione_UNIQUE` (`IdPrenotazione`),
  KEY `CodiceUtente` (`CodiceUtente`),
  CONSTRAINT `prenotazioniattivita_ibfk_1` FOREIGN KEY (`CodiceUtente`) REFERENCES `utente` (`CodiceID`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prenotazioniattivita`
--

LOCK TABLES `prenotazioniattivita` WRITE;
/*!40000 ALTER TABLE `prenotazioniattivita` DISABLE KEYS */;
INSERT INTO `prenotazioniattivita` VALUES (30,'12344',97);
/*!40000 ALTER TABLE `prenotazioniattivita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utente`
--

DROP TABLE IF EXISTS `utente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utente` (
  `CodiceID` varchar(10) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Cognome` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Ruolo` int NOT NULL,
  `Budget` double DEFAULT NULL,
  `DataFineSoggiorno` date DEFAULT NULL,
  PRIMARY KEY (`CodiceID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utente`
--

LOCK TABLES `utente` WRITE;
/*!40000 ALTER TABLE `utente` DISABLE KEYS */;
INSERT INTO `utente` VALUES ('10011','admin','admin','admin@gmail.it','admin',0,NULL,NULL),('12333','Francesco','Bernardini','fraberna@gmai.com','ciaociao',0,NULL,NULL),('12344','Eddy','Paciotta','eddy.paciotta@virgilio.com','panino98',1,48,'2021-01-11'),('12345','Luca','Ardovino','ardo@gmail.com','12345678',1,46,'2020-12-27'),('33003','Pippo','Pluto','pippopluto@gmail.it','client',1,100,'2021-10-23');
/*!40000 ALTER TABLE `utente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 13:17:01
